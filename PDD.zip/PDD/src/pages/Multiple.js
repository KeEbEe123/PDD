import React from "react";
import Bento2 from "../components/Bento2";
import BotpressChat from "../components/BotpressChat";
function Multiple() {
  return (
    <div>
      <BotpressChat />
      <Bento2 />
    </div>
  );
}

export default Multiple;
