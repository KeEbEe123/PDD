import React from "react";
import Bento from "../components/Bento";
import BotpressChat from "../components/BotpressChat";

function Rust() {
  return (
    <div>
      <BotpressChat />
      <Bento />
    </div>
  );
}

export default Rust;
