import React from "react";
import Bento1 from "../components/Bento1";
import BotpressChat from "../components/BotpressChat";

function Scab() {
  return (
    <div>
      <BotpressChat />
      <Bento1 />
    </div>
  );
}

export default Scab;
